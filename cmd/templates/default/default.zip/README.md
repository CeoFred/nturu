# microservice-template

The Makefile implements some useful targets:

* `build` - builds the `service` executable in `src/cmd`
* `tidy` - runs `go mod tidy` in the `src` folder
