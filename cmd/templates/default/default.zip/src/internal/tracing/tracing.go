package tracing

import (
	"github.com/nturu/microservice-template/version"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/trace"
)

var (
	tracer  = otel.Tracer(version.ServiceName)
	meter   = otel.Meter(version.ServiceName)
	rollCnt metric.Int64Counter
)

func Tracer() trace.Tracer {
	return tracer
}

func Meter() metric.Meter {
	return meter
}
