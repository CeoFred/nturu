package version

const ServiceName = "nturu-template"
const ServiceVersion = "0.1"
